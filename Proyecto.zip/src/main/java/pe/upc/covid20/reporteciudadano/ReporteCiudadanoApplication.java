package pe.upc.covid20.reporteciudadano;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReporteCiudadanoApplication {

    public static void main(String[] args) {
        SpringApplication.run(ReporteCiudadanoApplication.class, args);
    }

}
