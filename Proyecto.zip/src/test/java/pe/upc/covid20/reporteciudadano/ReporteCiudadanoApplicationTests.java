package pe.upc.covid20.reporteciudadano;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReporteCiudadanoApplicationTests {

    @Test
    void contextLoads() {
    }

}
